plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vortex.menu"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vortex.menu"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
