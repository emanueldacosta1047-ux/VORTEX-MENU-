package com.vortex.menu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Switch

class FloatingMenuService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubbleView: TextView? = null
    private var panelView: LinearLayout? = null
    private var panelOpen = false

    override fun onCreate() {
        super.onCreate()
        startVortexNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    private fun startVortexNotification() {
        val channelId = "vortex_menu_channel"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "VORTEX MENU",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }

        val stopIntent = Intent(this, FloatingMenuService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this, 77, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        val notification = builder
            .setContentTitle("VORTEX MENU ativo")
            .setContentText("A bolha flutuante está disponível.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(
                Notification.Action.Builder(
                    null, "Parar VORTEX", pendingStop
                ).build()
            )
            .build()

        startForeground(77, notification)
    }

    private fun windowType(): Int =
        if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun addBubble() {
        val bubble = TextView(this).apply {
            text = "V"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(88, 0, 150))
                setStroke(dp(3), Color.rgb(205, 65, 255))
            }
            elevation = dp(8).toFloat()
        }

        val params = WindowManager.LayoutParams(
            dp(58), dp(58), windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(190)
        }

        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var originX = 0
            private var originY = 0
            private var dragged = false

            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        originX = params.x
                        originY = params.y
                        dragged = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (kotlin.math.abs(dx) > dp(6) || kotlin.math.abs(dy) > dp(6)) {
                            dragged = true
                        }
                        params.x = originX + dx
                        params.y = originY + dy
                        try { windowManager.updateViewLayout(bubble, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragged) togglePanel()
                        return true
                    }
                }
                return false
            }
        })

        bubbleView = bubble
        windowManager.addView(bubble, params)
    }

    private fun togglePanel() {
        if (panelOpen) removePanel() else addPanel()
    }

    private fun addPanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.rgb(15, 11, 22))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(2), Color.rgb(185, 45, 255))
            }
            elevation = dp(12).toFloat()
        }

        val heading = TextView(this).apply {
            text = "VORTEX MENU"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(215, 145, 255))
            setPadding(0, 0, 0, dp(3))
        }
        val subheading = TextView(this).apply {
            text = "PAINEL DE ATALHOS"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(10))
        }
        panel.addView(heading)
        panel.addView(subheading)

        val demoOptions = listOf(
            "Relógio flutuante",
            "Efeito neon",
            "Atalho de captura",
            "Mostrar indicador visual"
        )
        demoOptions.forEach { label ->
            val toggle = Switch(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                isChecked = false
                setPadding(0, dp(3), 0, dp(3))
            }
            panel.addView(toggle)
        }

        val close = TextView(this).apply {
            text = "FECHAR MENU"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.rgb(120, 0, 180))
                cornerRadius = dp(12).toFloat()
            }
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { removePanel() }
        }
        val stop = TextView(this).apply {
            text = "DESATIVAR BOLHA"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 115, 115))
            setPadding(dp(8), dp(12), dp(8), dp(4))
            setOnClickListener { stopSelf() }
        }
        panel.addView(close)
        panel.addView(stop)

        val panelParams = WindowManager.LayoutParams(
            dp(285), WindowManager.LayoutParams.WRAP_CONTENT, windowType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        panelView = panel
        windowManager.addView(panel, panelParams)
        panelOpen = true
    }

    private fun removePanel() {
        panelView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panelView = null
        panelOpen = false
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        removePanel()
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubbleView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.vortex.menu.STOP"
    }
}
