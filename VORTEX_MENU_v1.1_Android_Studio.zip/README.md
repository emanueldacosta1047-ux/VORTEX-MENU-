# VORTEX MENU — versão 1.1

Projeto Android independente, com uma bolha flutuante e um painel de atalhos demonstrativos.

## Incluído
- Bolha roxa com V, arrastável.
- Abre/fecha o painel ao tocar.
- Interruptores demonstrativos.
- Botão para fechar o painel.
- Botão para desativar a bolha.
- Ação para parar o serviço pela notificação.
- Tema preto e roxo.

## Compilar
É necessário um computador com Android Studio:
1. Extrair o ZIP.
2. Abrir a pasta no Android Studio.
3. Esperar pelo Gradle Sync.
4. Usar Build > Build APK(s).
5. O APK debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Ativar no Android
1. Instalar e abrir VORTEX MENU.
2. Tocar em ATIVAR VORTEX.
3. Autorizar "Aparecer por cima de outras aplicações".
4. Voltar e ativar a bolha.
5. Arrastar a bolha e tocar para abrir o painel.

## Limites importantes
Os interruptores são demonstrativos nesta versão. O aplicativo não altera ficheiros, memória ou funcionamento do Rio Rise e não contorna anti-cheat. A permissão de sobreposição permite mostrar a interface por cima de outras aplicações; concede-a apenas a aplicações em que confies.
