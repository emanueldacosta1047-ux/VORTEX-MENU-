package com.vortex.menu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 30, 26, 30)
            setBackgroundColor(Color.rgb(10, 8, 16))
        }

        val title = TextView(this).apply {
            text = "VORTEX MENU"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(198, 110, 255))
        }
        val description = TextView(this).apply {
            text = "ATALHO FLUTUANTE  •  VERSÃO 1.1\n\nAtiva a bolha e abre o painel por cima das tuas aplicações."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 18, 0, 22)
        }
        val activate = Button(this).apply {
            text = "ATIVAR VORTEX"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else {
                    val service = Intent(this@MainActivity, FloatingMenuService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(service)
                    } else {
                        startService(service)
                    }
                    finish()
                }
            }
        }
        val stop = Button(this).apply {
            text = "PARAR BOLHA"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingMenuService::class.java))
            }
        }
        val footer = TextView(this).apply {
            text = "Os controlos do painel são demonstrações e atalhos visuais. Não alteram o Rio Rise."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 0)
        }

        page.addView(title)
        page.addView(description)
        page.addView(activate)
        page.addView(stop)
        page.addView(footer)
        setContentView(page)
    }
}
